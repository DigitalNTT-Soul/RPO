module_prerequisites = {"s00002":"0.0.2", "e00002":"0.0.1"}

module_name = "Seven Seas of Hope"
module_version = "0.0.1"
module_manifest = []