module_prerequisites = {"s00000001":"0.0.1", "e00000001":"0.0.1"}

module_name = "Never-Sweat Junction"
module_version = "0.0.1"
module_manifest = [
    './module_main.py',
    './assets/images/NeverSweat Junction Logo 8k.png',
    './assets/images/The Wagon 1080p.png'
]