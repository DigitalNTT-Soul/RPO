expansion_name = "Freakin' Aliens!"
expansion_prerequisites = {"s00000001":"0.0.1"}
expansion_version = "0.0.1"
expansion_manifest = []