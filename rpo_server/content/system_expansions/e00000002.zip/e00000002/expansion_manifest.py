expansion_name = "Cosmic Creatures"
expansion_prerequisites = {"s00002":"0.0.2"}
expansion_version = "0.0.1"
expansion_manifest = []