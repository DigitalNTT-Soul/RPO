system_name = "World of Blades and Magic"
system_version = "0.0.2"
system_manifest = []