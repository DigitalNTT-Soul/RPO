system_name = "Never-Sweat Junction"
system_version = "0.0.1"
system_manifest = []